export const URL= {
    JIRAURL: 'https://id.atlassian.com/login'
}

export const RUTAS = {
    matriz : './resources/MatrizDeEjecucion.xlsx'
 }

export const CREDENTIALS = {
 CORREO : 'icarrazco@eglobal.com.mx',
 PASSWORD: 'Temporal2024*'

}
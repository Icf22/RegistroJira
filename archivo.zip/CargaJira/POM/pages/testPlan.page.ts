import { Locator, Page } from "@playwright/test";
import { RUTAS } from "../data/constantes";
import * as XLSX from 'xlsx';
import {BasePage} from "../pages/base.page"


export class TestPlan extends BasePage{
    readonly page : Page;
    txtCorreo: Locator;
    txtBusqueda: Locator;
    txtFielStep1: Locator;
    txtFieldData2: Locator;
    txtFieldResult3: Locator;
    btnAdd: Locator;
    page_carga: Locator;


    constructor(page : Page) {
       super(page);
       this.txtBusqueda = page.locator('[data-test-id="search-dialog-input"]');
       this.page_carga = page.getByTestId('issue.views.issue-base.foundation.breadcrumbs.project.item')
       this.txtFielStep1 = page.locator('#zs-field-step--1');
       this.txtFieldData2 = page.locator('#zs-field-data--1');
       this.txtFieldResult3 = page.locator('#zs-field-result--1');
       this.btnAdd = page.getByTitle('Add Steps').getByRole('img');
    }

    async registrarMatriz(){
        try {
            const filePath = RUTAS.matriz;
            const workbook = XLSX.readFile(filePath);
            const nameSheet = 'FUNCIONAL POSITIVO'
            const worksheet = workbook.Sheets[nameSheet];
            const lastRow = XLSX.utils.sheet_to_json(worksheet).length + 1;
            //this.datosPublicos = XLSX.utils.sheet_to_json(worksheet);
            //await this.page.waitForLoadState("domcontentloaded");
            // await this.txtBusqueda.click();
            // await this.txtBusqueda.fill('GSC-17621'); 
            //await this.page.locator('[data-test-id="search-dialog-input"]').press('Enter');
            for (let i = 16; i <= lastRow  ; i++) {  
                try {
                    let nombrePrueba = worksheet['E' + i] ?. w || '';
                    let precondiciones = worksheet['F' + i] ?. w || '';
                    let script = worksheet['H' + i] ?. w || '';
                    //await this.page.waitForLoadState("domcontentloaded");
                    //await this.page.getByRole('link', { name: 'GSC-17696'}).click();
                    await this.page.waitForSelector('._1reo15vq _1ke8ftgi _1suq18uv _aaynrg55 _155a19bv _v564cxtv _c71l19kl _18m91wug');
                    //await this.page.waitForTimeout(20000);
                    await this.txtFielStep1.fill(nombrePrueba);
                    await this.txtFieldData2.fill(precondiciones);
                    await this.txtFieldResult3.fill(script);
                    await this.btnAdd.click();
                          
                } catch (error) {
                    console.log('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                   // await this.handleError("Error en la fila  " + i + ":", error);
                }
            }
        } catch (error) {
            console.log('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
            //await this.handleError("Error al cargar el archivo de excell", error);
        }
    }
}

















  
  
  